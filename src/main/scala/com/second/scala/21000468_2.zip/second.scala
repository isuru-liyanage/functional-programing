package com.second.scala


object second {
  def main(args: Array[String]) {
    val a: Int = 2
    val b: Int = 3
    val c: Int = 4
    val d: Int = 5
    val k: Float = 4.3f

    // Expression a

//    println(--a)
//
//    // Expression b
//    println({
//      a += 1; a - 1
//    })
//
//    // Expression c
//    val g: Float = 0.0f
//    println(-2 * (g - k) + c)
//
//    // Expression d
//    val previousC = c
//    c += 1
//    println(previousC)
//
//    // Expression e
//    val previousC2 = c
//    val previousA = a
//    c += 1
//    a += 1
//    println(previousC2 * previousA)


  }
}
