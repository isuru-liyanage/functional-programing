package com.second.scala

object first {
  def main(args: Array[String]) {
    var i, j, m, n, k: Int = 2
    var f, g: Float = 12.0f
    var c: Char = 'X'

    val resultA = k + 12 * m
    val resultB = m / j
    val resultC = n % j
    val resultD = m / j * j
    val resultE = f + 10 * 5 + g
    i += 1
    val resultF = i * n

    println(s"Result A: $resultA")
    println(s"Result B: $resultB")
    println(s"Result C: $resultC")
    println(s"Result D: $resultD")
    println(s"Result E: $resultE")
    println(s"Result F: $resultF")


  }
}
