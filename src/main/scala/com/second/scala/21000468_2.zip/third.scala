package com.second.scala


object third {
  def main(args: Array[String]) {
    def calculateTakeHomeSalary(normalHours: Int, otHours: Int): Double = {
      val normalRate: Double = 250.0
      val otRate: Double = 85.0
      val taxRate: Double = 0.12

      val normalPay: Double = normalHours * normalRate
      val otPay: Double = otHours * otRate
      val grossPay: Double = normalPay + otPay
      val taxAmount: Double = grossPay * taxRate
      val takeHomeSalary: Double = grossPay - taxAmount

      takeHomeSalary
    }

    val normalHours = 40
    val otHours = 30

    val takeHomeSalary = calculateTakeHomeSalary(normalHours, otHours)
    println(s"The take-home salary is Rs. $takeHomeSalary")


  }
}
