package com.second.scala

import scala.math.BigDecimal.double2bigDecimal

object fourth {
  def main(args: Array[String]) {
    def calculateProfit(ticketPrice: Double): Double = {
      val baseAttendance = 120
      val attendanceIncrease = 20
      val costPerPerformance = 500.0
      val costPerAttendee = 3.0

      val attendance = baseAttendance + (ticketPrice - 15) / 5 * attendanceIncrease
      val revenue = attendance * ticketPrice
      val cost = costPerPerformance + attendance * costPerAttendee
      val profit = revenue - cost

      profit
    }

    val ticketPrices = List(10.0, 10.5, 11.0, 11.5, 12.0, 12.5, 13.0, 13.5, 14.0, 14.5, 15.0, 15.5, 16.0, 16.5, 17.0, 17.5, 18.0, 18.5, 19.0, 19.5, 20.0)
    val profits = ticketPrices.map(calculateProfit)
    val bestPriceIndex = profits.indexOf(profits.max)
    val bestPrice = ticketPrices(bestPriceIndex)
    val bestProfit = profits(bestPriceIndex)

    println(s"The best ticket price for maximum profit is Rs. $bestPrice")
    println(s"The maximum profit is Rs. $bestProfit")
  }

}
